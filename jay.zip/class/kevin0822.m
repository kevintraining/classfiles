%% Start from scratch.
% clear classes  %#ok<CLCLS>
clear all %#ok<CLALL>
rng(123, 'twister')

%%
fs = 100;
t  = (0:1e7) / fs;
x  = 0.02*cos(2*pi*10*t);
x  = x + randn(size(x));
x  = ckhsig(x, fs);

%%
figure(1)
clf
ckhsigpsd(x, 'r', 2^20, 'Hz', kaiser(2^20, 19), 'max');
ylim([-30 0])
figure(2)
clf
ckhsigpsd(x, 'r', 2^20, 'Hz', kaiser(8192, 19), 'max');
ylim([-30 0])
